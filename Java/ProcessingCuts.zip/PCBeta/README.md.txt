Ett litet macro-script skapat i autohotkey, som innehåller kortkommandon för dem vanligaste strukturerna.

Jag har använt detta för att snabba upp arbetsflödet när jag skissar i processing (java)

För att komma igång:
 * Starta först ProcessingCuts
 * Starta processing i java-läge eller gör till aktivt fönster
    (scriptet vilar när processing är ett bakgrundsfönster)
 * Tryck F1 för att se hjälpskärmen

Ha det så roligt och skriv gärna en rad med glada tillrop eller varsko mig om buggar
om ni råkar på!

alex@wigforss.nu